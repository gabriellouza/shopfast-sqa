import 'package:flutter/material.dart';
import 'screens/login_screen.dart'; // Certifique-se de que o caminho está correto
import 'screens/place_list_screen.dart';
import 'screens/place_detail_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Acesso Já',
      theme: ThemeData(primarySwatch: Colors.blue),
      initialRoute: '/',
      routes: {
        '/': (context) => const LoginScreen(), // Tela inicial de login
        '/places': (context) =>
            const PlaceListScreen(), // Tela de lista de locais
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/placeDetails') {
          // Verifica se os argumentos foram passados corretamente
          final Map<String, dynamic>? place =
              settings.arguments as Map<String, dynamic>?;
          if (place != null) {
            return MaterialPageRoute(
              builder: (context) => PlaceDetailScreen(
                place: place,
                userName: 'Usuário AcessoJá',
              ),
            );
          } else {
            // Retorna uma tela de erro se os argumentos estiverem ausentes
            return MaterialPageRoute(
              builder: (context) => Scaffold(
                appBar: AppBar(title: const Text('Erro')),
                body: const Center(
                    child: Text('Detalhes do local não encontrados!')),
              ),
            );
          }
        }
        return null; // Retorna null para rotas não reconhecidas
      },
    );
  }
}
